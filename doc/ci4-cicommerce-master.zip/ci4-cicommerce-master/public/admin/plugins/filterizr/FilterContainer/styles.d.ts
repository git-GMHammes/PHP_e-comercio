import FilterizrOptions from '../FilterizrOptions';
export declare const makePaddingStyles: (options: FilterizrOptions) => object;
export declare const makeInitialStyles: (options: FilterizrOptions) => object;
export declare const makeHeightStyles: (height: number) => object;
