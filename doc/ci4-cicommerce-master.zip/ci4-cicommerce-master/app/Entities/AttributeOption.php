<?php namespace App\Entities;

use CodeIgniter\Entity;

class AttributeOption extends Entity
{
    protected $dates = ['created_at', 'updated_at'];
}
